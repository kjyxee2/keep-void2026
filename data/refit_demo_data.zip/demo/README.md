# RE:FIT 시연 데이터 (안산 산단 폐기물 흐름, 2026-07 기준)

작성 2026-11-07. 재현: `python3 -I scripts/demo_build.py <research/waste 경로>` (네트워크 없이 캐시만 읽음, 2초 내외). 지오코딩 캐시를 다시 채우려면 같은 명령 끝에 `geocode`를 붙인다(OSM Nominatim, 초당 1건 이하).

## 0. 먼저 알아둘 것(한계)

1. **건수이지 톤수가 아니다.** 흐름의 모든 비율은 배출자 신고 행 수 기준이다. 1행이 연 1톤인지 1,000톤인지 모른다. 톤수와 비용은 `summary.json`의 `volume_cost_2024`(W2 추정)만 쓴다.
2. **신고 계약이지 실제 운반이 아니다.** 안산시 배출자 신고현황(산단환경과) 2026-07-10 게시본에 적힌 운반자와 처리업체 목록이다. 그해 실제로 보냈는지는 모른다.
3. **처리방식은 허가 업종으로 추정했다.** 처리업체가 가진 허가(2023 전국 처리업체 현황, 안산시 목록, 올바로)와 그 행의 폐기물군을 맞춰 판정했다(W1 1.2절과 같은 규칙). 재활용 허가 목록은 2023년 기준이다.
4. **거리는 직선이다.** 공장 좌표에서 처리업체 좌표까지 하버사인 직선거리다. 도로 거리는 보통 1.2~1.4배다. 처리업체 좌표 상당수가 시군구 중심 대체라 `distance_quality`를 꼭 같이 보여 준다.
5. **fit_candidates는 추천 근거 데모다.** "같은 폐기물군을 다른 안산 공장이 이미 물질 재활용 업체로 보내고 있다"는 신고 근거만 쓴다. 실제로 그 업체가 이 공장의 폐기물(성상, 오염도, 수량)을 받을 수 있는지는 **반드시 업체 확인이 필요하다.** 폐합성수지류처럼 한 코드에 단일 재질과 오염 복합재가 섞인 종류는 특히 그렇다.
6. **좌표는 지어내지 않았다.** 출처를 `coord_source`에 남겼다. 대체 좌표(동 중심, 단원구 중심, 시군구 중심)는 지도에서 흐리게 또는 다른 모양으로 표시할 것.
7. 개인정보(대표자 이름, 전화번호, 이메일)는 넣지 않았다. 공장 이름과 주소는 공개 신고현황에 있는 사업장 정보다.

## 1. 기준

- 기간: 2026-07 게시본, **W1 B 기준(공장 상시 배출)**. 원본 8,417행에서 석면 2,138, PCB 함유 554, 개인/일시 배출자 320, 자원순환과 명단과 중복 830행을 뺀 **4,575행**(사업장일반 3,572, 지정 1,003), 배출 사업장 1,234곳, 처리업체 796곳(같은 회사 표기 통합).
- 폐기물군: `scripts/wastegroup.py`. 처리방식, 지역, 처리업체 통합: `scripts/analyze_flows.py` 함수를 그대로 가져다 썼다(`demo_build.py`가 import).
- 검증(빌드 끝에 출력, assert): 고유 flow_id 4,575 = W1 2026 B 행 수, 가중합 4,575.0, 공장 1,234, 처리업체 796, 안산 안 17.1%, 경기 밖 36.4%, 상위 10곳 24.6%, 같은 종류 다른 처리 26.6%(모두 W1 값과 일치).

## 2. 파일과 열

### factories.csv (1,234행, 배출 공장 1곳 1행)

| 열 | 설명 |
|---|---|
| id | F0001~ |
| name | 신고 사업장명 |
| address | 신고 주소(원본의 밑줄을 쉼표로) |
| dong | 주소 괄호 속 법정동 |
| lat, lng | WGS84 |
| coord_source | `datagokr(상호+주소)`: 공공데이터포털 15170508 배출신고 현황(2026-04-30)에서 상호와 도로명주소가 모두 맞는 지점. `datagokr(주소)`: 도로명+건물번호만 일치. `datagokr(상호)`, `datagokr(상호 유사)`: 이름만 일치. `지오코딩(OSM 도로 단위)`: OSM Nominatim으로 도로명까지만 찾은 점(도로 중간점, 수백 m~수 km 오차). `동 중심 대체`: datagokr 같은 동 지점들의 중앙값. `단원구 중심 대체`: 주소가 없거나 동을 모를 때 |
| waste_types | 신고 폐기물 종류 원 표기, JSON 배열 문자열 |
| waste_groups | 폐기물군, JSON 배열 문자열 |
| n_waste_types, n_processors, n_flows | 종류 수, 고유 처리업체(회사) 수, 신고 행 수 |
| sheets | `사업장일반`, `지정` |
| small_emitter_proxy | 신고 폐기물 종류 2개 이하면 true. **소량 배출 대리지표**(톤수가 없어서). W2 기준 비의료 신고 사업장의 61%가 품목 2개 이하 |

### processors.csv (796행, 처리업체 회사 1곳 1행)

| 열 | 설명 |
|---|---|
| id | P0001~ (2026 B 기준 행 수 많은 순) |
| name | 정규업체명(`processors_enriched.csv`의 `정규업체명`) |
| name_variants | 신고에 쓰인 이름 표기들(JSON) |
| sido, sigungu, address | 소재지(2023 전국 현황, 안산시 목록, 올바로 순) |
| lat, lng, coord_source | 안산 소재 업체는 datagokr 이름 매칭, 그 밖은 OSM 지오코딩(도로, 리/동, 읍면 단위), 안 되면 `시군구 중심 대체`(통계청 2013 시군구 경계 면적 중심). 소재지를 모르는 업체는 좌표 없음 |
| business_type | 2023 현황 업종(없으면 올바로 업종코드) |
| method | 2026 B 흐름에서 이 업체로 가는 행의 처리방식 중 가장 많은 것. 값: 소각, 에너지회수, 물질재활용, 중간가공(R10), 매립, 기타 중간처분, 자가처리, 미확인 |
| methods_2026 | 처리방식별 행 수(JSON). 같은 업체도 폐기물군에 따라 방식이 다를 수 있다 |
| permit_summary, r_types, r_types_by_group | 허가 요약, 재활용 R 유형, 폐기물군별 R 유형(근거 확인용) |
| incinerator_ton_per_day, landfill_m3, capacity | 2023 현황 소각 용량(톤/일), 매립 용량(m3) |
| confirmed | `confirm_status`가 "확인"으로 시작하면 true(공식 목록 일치) |
| confirm_status | 확인(2023 전국 현황), 확인(안산시 현황), 부분확인(올바로 처리자 등록), 추정(별칭 근거), 미확인 |
| flows_2026, n_factories_2026 | 받는 신고 행(가중), 거래 공장 수 |

### flows.csv (4,620행 = 처리업체 링크, 고유 flow_id 4,575)

원본 1행에 처리업체가 k곳 적혀 있으면 k개 링크로 나누고 `weight = 1/k`. 비율은 **weight 합 / 4,575**로 구하면 W1과 같다.

| 열 | 설명 |
|---|---|
| link_id, flow_id | 링크 번호, 원본 신고 행 번호 |
| period, sheet | 2026-07, 사업장일반 또는 지정 |
| factory_id, processor_id | FK. 처리업체 칸이 빈 행은 processor_id 공란 |
| processor_name_raw | 신고 원문 처리업체 이름 |
| transporter, transporter_is_processor | 운반자, 운반자와 처리업체가 같은 회사인지 |
| waste_type, waste_group | 원 표기, 폐기물군 |
| method | 위 7개 값 + 미확인. W1 "물질 재활용(다른 폐기물군 허가)"는 물질재활용으로 묶고 `method_by_other_group_permit = true` |
| method_detail | W1 원 분류 |
| in_ansan, region | 처리업체 소재지 기준. region: 안산, 시흥, 경기 기타, 경기 밖, 미확인. `region_w1`은 W1 7구분 |
| distance_km | 공장-처리업체 직선거리(근사) |
| distance_quality | A 지점-지점, B 도로/리 단위 포함, C 동 중심 포함, D 시군구 중심 포함. 처리업체 좌표가 없으면 공란 |
| weight | 1/k |

### fit_candidates.csv (RE:FIT 추천 근거 데모)

대상: 지금 소각, 에너지회수, 매립 업체로 보내는 (공장, 폐기물군, 현재 처리업체) 조합. 의료폐기물(법상 소각)과 "그 밖의 폐기물"(성분 불명 묶음)은 제외.
후보: 같은 폐기물군을 **자기 폐기물군 허가로 물질 재활용**(R1~R7, R11) 판정을 받은 경로로 이미 받고 있는 처리업체. 그 공장이 이미 그 폐기물군을 보내는 업체는 뺐다. 상위 3곳.

| 열 | 설명 |
|---|---|
| factory_id, factory_name, waste_group | |
| current_processor_id, current_processor_name, current_method | 현재 처리업체와 방식(소각, 에너지회수, 매립) |
| candidate_processor_id, candidate_name, candidate_sigungu | 후보 |
| rank | 1~3 |
| evidence_rows | 이 후보에 같은 폐기물군을 물질 재활용으로 보내는 **다른** 안산 공장 수 |
| distance_km, distance_quality | 공장-후보 직선거리 |
| candidate_confirmed | 후보 업체가 공식 목록에서 확인되었는지 |
| factory_already_recycles_group | 이 공장이 같은 폐기물군을 이미 다른 물질 재활용 업체에도 보내는지(분산 계약 신호) |
| fit_score | 0~100, 아래 산식 |

**fit_score 산식**

```
fit_score = 100 x (0.5 x E + 0.3 x D + 0.2 x M)
E (실적 경로) = ln(1 + evidence_rows) / ln(1 + 그 폐기물군에서 가장 많은 evidence_rows)
D (거리)      = max(0, 1 - distance_km / 150), 거리를 모르면 0
M (처리방식)  = 0.6 x 전환 이득 + 0.4 x 후보 확인 가중
                전환 이득: 현재 매립 1.0, 소각 0.8, 에너지회수 0.6
                후보 확인 가중: confirmed 1.0, 아니면 0.5
```

순위는 fit_score, 동점이면 evidence_rows, 거리 순. 가중치는 시연용 가정이며 화면에서 바꿀 수 있게 하는 것을 권한다.

### group_fit.csv (공동 수거, 공동 계약 후보)

같은 폐기물군을 신고한 **소량 배출 대리 공장**(`small_emitter_proxy = true`) 가운데 좌표가 datagokr 지점인 공장만 썼다(대체 좌표로 묶으면 가짜 근접이 생김). 의료폐기물 제외. 폐기물군마다 반복: 반경 2km 안 이웃이 가장 많은 공장을 씨앗으로 가까운 순 최대 10곳을 묶고, 중심에서 2km 넘는 공장은 빼고, 3곳 이상이면 그룹으로 확정한 뒤 남은 공장으로 다시 반복.

| 열 | 설명 |
|---|---|
| group_id, waste_group | |
| factory_ids | JSON 배열 |
| n | 3~10 |
| centroid_lat, centroid_lng, max_dist_km | 구성 공장 평균 좌표, 중심에서 가장 먼 공장까지 거리 |
| dongs | 법정동 |
| current_methods | 구성 공장의 그 폐기물군 처리방식별 행 수(JSON) |
| shared_processor_ids | 구성 공장 2곳 이상이 이미 같이 쓰는 처리업체(공동 계약 시작점) |
| n_distinct_processors | 구성 공장들이 쓰는 처리업체 수(분산 정도) |

한 공장이 여러 폐기물군 그룹에 들어갈 수 있다.

### unit_prices.csv (단가)

W2 5.1절 단가표와 `scripts/04_cost.py` 시나리오를 옮긴 것. 부가세와 운반비 별도가 원칙.

| 열 | 설명 |
|---|---|
| category | 사업장일반, 지정, 공통 |
| item, waste_group | 원 품목명, 대응 폐기물군(대응이 애매하면 공란) |
| method | 소각, 매립, 재활용(고시 재활용업자 위탁), 물질재활용(시연), 운반 등 |
| scenario | 시연 계산용 행만 하한, 기준, 상한 |
| price_won, price_min, price_max, unit | 원/톤(운반 가산은 원/톤/10km) |
| year, source_code, source, source_nature | 연도, W2 출처 번호, 출처명, 성격(고시, 업계, 시장, 약함, 추정) |

시연 절감액(가설): `연 절감액 = 톤 x (현재 방식 단가 - 물질재활용 단가)`. `source_code = W2calc`, `scenario = 기준` 행을 쓰면 W2 915억원 추정과 같은 가정이다. 공장별 톤수는 공개 자료에 없으므로 사용자가 입력하게 할 것.

### summary.json (대시보드 핵심 지표)

모든 값에 `basis`(건수 기준 또는 추정)를 붙였다. 주요 키: `counts`, `region_pct`(안산 17.1, 시흥 5.6, 경기 기타 31.9, 경기 밖 36.4, 미확인 8.9), `outside_ansan_pct_of_located`(81.2), `method_pct`, `burn_vs_material`(태움 33.3 대 물질 재활용 27.7), `same_type_different_treatment`(1,218.7행, 26.6%), `top10_processor_share_pct`(24.6), `transporter_is_processor_pct`, `trend_2023_2026`(시점별 B 기준 지표), `volume_cost_2024`(공장 범위 위탁 54만 9천톤, 연 처리비 하한 519억, 기준 915억, 상한 1,488억원, 추정), `coords`(좌표 출처별 개수), `fit_candidates`, `group_fit`.

### refit_demo.sqlite

위 6개 CSV와 같은 테이블 + `summary`(json 1행). 모든 열이 TEXT로 들어가 있으니 숫자 비교 시 CAST.

## 3. Supabase에 넣기

1. SQL Editor에서 아래 CREATE TABLE 실행.
2. Table Editor의 CSV 가져오기로 factories → processors → flows → fit_candidates → group_fit → unit_prices 순서로 올린다(FK 순서). 또는 `psql`로 `\copy factories from 'factories.csv' csv header` 식으로 넣는다. 빈 칸은 NULL로 들어간다.
3. `summary.json`은 정적 파일로 두거나 `app_summary` 테이블에 jsonb 1행으로 넣는다.

```sql
create table factories (
  id text primary key, name text not null, address text, dong text,
  lat double precision, lng double precision, coord_source text,
  waste_types jsonb, waste_groups jsonb, n_waste_types int, n_processors int, n_flows int,
  sheets jsonb, small_emitter_proxy boolean
);
create table processors (
  id text primary key, name text not null, name_variants jsonb, sido text, sigungu text, address text,
  lat double precision, lng double precision, coord_source text, business_type text,
  method text, methods_2026 jsonb, permit_summary text, r_types text, r_types_by_group text,
  incinerator_ton_per_day double precision, landfill_m3 double precision, capacity text,
  confirmed boolean, confirm_status text, flows_2026 double precision, n_factories_2026 int
);
create table flows (
  link_id int primary key, flow_id int not null, period text, sheet text,
  factory_id text references factories(id), processor_id text references processors(id),
  processor_name_raw text, transporter text, transporter_is_processor boolean,
  waste_type text, waste_group text, method text, method_detail text, method_by_other_group_permit boolean,
  in_ansan boolean, region text, region_w1 text, distance_km double precision, distance_quality text,
  weight double precision
);
create table fit_candidates (
  id bigint generated always as identity primary key,
  factory_id text references factories(id), factory_name text, waste_group text,
  current_processor_id text references processors(id), current_processor_name text, current_method text,
  candidate_processor_id text references processors(id), candidate_name text, candidate_sigungu text,
  rank int, evidence_rows int, distance_km double precision, distance_quality text,
  candidate_confirmed boolean, factory_already_recycles_group boolean, fit_score double precision
);
create table group_fit (
  group_id text primary key, waste_group text, factory_ids jsonb, n int,
  centroid_lat double precision, centroid_lng double precision, max_dist_km double precision,
  dongs jsonb, current_methods jsonb, shared_processor_ids jsonb, n_distinct_processors int
);
create table unit_prices (
  id text primary key, category text, item text, waste_group text, method text, scenario text,
  price_won double precision, price_min double precision, price_max double precision, unit text,
  year int, source_code text, source text, source_nature text, note text
);
create index on flows (factory_id); create index on flows (processor_id); create index on flows (waste_group);
create index on fit_candidates (factory_id, waste_group, rank);
```

fit_candidates CSV에는 id 열이 없으니 가져오기 때문에 identity 열은 비워 둔다. 공개 시연이면 RLS를 켜고 `select`만 anon에 허용한다.

자주 쓸 쿼리 예:

```sql
-- 안산 안 처리 비율(건수 기준)
select round(100 * sum(weight) filter (where in_ansan) / 4575.0, 1) from flows;
-- 공장 1곳의 추천
select * from fit_candidates where factory_id = 'F0001' order by waste_group, rank;
```

## 4. 출처

- 흐름: 안산시 사전정보공표 폐기물 배출자 신고현황(산단환경과) 2026-07-10(게시글 1677014), 2023-07, 2024-09, 2025-07(추이). `flows/`
- 처리업체 속성: `processors_enriched.csv`(2023 전국 폐기물 처리업체 현황, 안산시 처리업체 현황 2026-07, 올바로 공개 업체검색, 별칭표). 상세는 W1 1장.
- 공장 좌표: 공공데이터포털 「경기도 안산시_사업장 폐기물 배출신고 현황_20260430」(15170508). `raw/datagokr_15170508/`
- 지오코딩: OpenStreetMap Nominatim(© OpenStreetMap contributors, ODbL). 캐시 `raw/geocode_osm_202611/nominatim_cache.jsonl`. 도로나 리 단위라 건물 위치가 아니다. 결과가 그 시군구 중심에서 30km(공장은 단원구 중심 15km) 넘게 떨어지면 버렸다. 시간 때문에 처리업체는 행 수 상위 약 300곳까지만 조회했고 나머지는 시군구 중심 대체다(`geocode` 모드를 다시 돌리면 이어서 채우고, 빌드를 다시 하면 반영된다). OSM 공장 좌표는 같은 동 datagokr 중심과 중앙값 1.3km(최대 5.1km) 차이였다.
- 좌표 현황(2026-11-07 빌드): 공장 1,234곳 = datagokr 1,139(92.3%), OSM 도로 76(6.2%), 동 중심 13(1.1%), 단원구 중심 6(0.5%). 처리업체 796곳 = datagokr 22(2.8%), OSM 334(42.0%: 도로 145, 리/동 41, 읍면 148), 시군구 중심 246(30.9%), 좌표 없음 194(24.4%, 소재지 미확인 업체). flows 가중 기준 거리 품질: A 15.8%, B 62.3%, C 0.2%, D 12.6%, 거리 없음 9.0%.
- 시군구 중심: 통계청 2013 시군구 경계(southkorea-maps) `raw/geo/`
- 물량, 비용, 단가: W2(`W2_물량과비용.md`, `data/ansan_cost_2024_items.csv`), 원 출처는 unit_prices.csv `source`
