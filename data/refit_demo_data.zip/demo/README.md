# RE:FIT 시연 데이터 (안산 산단 폐기물 흐름, 2026-07 기준)

작성 2026-11-07. 재현: `python3 -I scripts/demo_build.py <research/waste 경로>` (네트워크 없이 캐시만 읽음, 수 초). 건물 단위 좌표 캐시를 다시 채우려면 같은 명령 끝에 `geocode`를 붙인다(OSM Nominatim, 초당 1건 이하). 진단 칩과 물량 선택지 정의는 `scripts/chips_data.py`에 있다.

**원칙: 시연 데이터에는 실제 공개 자료의 값과 그 값을 단순 집계한 값(건수, 비율)만 넣었다.** 추정 금액, 시나리오 단가, 계수를 곱한 단가, 대체 좌표, 대리지표는 모두 뺐다. 마대 환산도 공식 근거가 있는 품목만 kg을 넣었다.

## 0. 먼저 알아둘 것(한계)

1. **건수이지 톤수가 아니다.** 흐름의 모든 비율은 배출자 신고 행 수 집계다. 1행이 연 1톤인지 1,000톤인지 모른다. 톤수는 `summary.json`의 `official_stats_2024_ansan_ton`(공식 통계 원값, 안산시 전체)만 있다. 공장별 톤수와 처리비는 공개 자료에 없으므로 화면에서 사용자가 입력한다.
2. **신고 계약이지 실제 운반이 아니다.** 안산시 배출자 신고현황(산단환경과) 2026-07-10 게시본에 적힌 운반자와 처리업체 목록이다. 그해 실제로 보냈는지는 모른다.
3. **처리방식은 허가 업종 기준이다.** 처리업체가 가진 허가(2023 전국 처리업체 현황, 안산시 목록, 올바로)와 그 행의 폐기물군을 맞춰 정했다. 그 폐기물군에 쓸 수 있는 허가(폐기물군별 재활용 R 유형, 소각, 매립, 기타 중간처분)가 2개 이상인 업체는 하나를 고르지 않고 `복수 허가`로 두었다. 재활용 허가 목록은 2023년 기준이다.
4. **좌표는 건물 위치로 확인된 것만 남겼다.** 공장 1,123곳, 처리업체 32곳. 나머지는 lat, lng가 비어 있다(5절). 처리업체 좌표가 적어서 **거리 계산이 되는 흐름은 가중 기준 14.3%뿐이다.** 거리는 하버사인 직선거리다.
5. **fit_candidates는 신고 근거 목록이다.** "같은 폐기물군을 다른 안산 공장이 이미 물질 재활용 허가 업체로 보내고 있다"는 신고 사실만 쓴다. 그 업체가 이 공장의 폐기물(성상, 오염도, 수량)을 실제로 받을 수 있는지는 **반드시 업체 확인이 필요하다.**
6. **물질재활용 위탁 단가는 공개 원문이 없다.** unit_prices.csv에 있는 재활용업자 단가는 방치폐기물 처리이행보증보험금 산출용 고시 단가이고 실제 위탁 거래가가 아니다. 그래서 절감액 계산식은 싣지 않았다.
7. 개인정보(대표자 이름, 전화번호, 이메일)는 넣지 않았다. 공장 이름과 주소는 공개 신고현황에 있는 사업장 정보다.

## 1. 기준

- 기간: 2026-07 게시본, **W1 B 기준(공장 상시 배출)**. 원본 8,417행에서 석면 2,138, PCB 함유 554, 개인/일시 배출자 320, 자원순환과 명단과 중복 830행을 뺀 **4,575행**(사업장일반 3,572, 지정 1,003), 배출 사업장 1,234곳, 처리업체 803곳(같은 회사 표기 통합. W1은 796곳이었으나 아래 별칭 규칙으로 7곳이 분리됨).
- **별칭 규칙**: 업체 매칭 자체가 추정인 이름(`processors_enriched.csv` 확인상태가 `추정(별칭 근거)`, `별칭중간`, `별칭낮음`인 20개 이름)은 매칭으로 붙인 소재지, 업종, 허가, 처리방식, 용량, 좌표를 모두 비우고 다른 회사로 합치지 않았다. confirm_status는 `미확인(별칭 매칭 제외)`(14곳). 이 업체로 가는 흐름은 region, in_ansan, method가 미확인이다. 대상: 자가, 자가처리, 수도권매립지, 수도권매립지관리공사, 서청개발, (주)제이에이그린, (주)이에스청주 계열, (주)이에스지 계열(에코비트에너지진천, 세종으로 붙였던 것), (주)이에스청원 계열, 스테리싸이클코리아, 삼우그린, (주)에너지진천. 이름 목록은 `summary.json`의 `alias_rule`.
- 남긴 별칭(`별칭높음` 2건): (1) 케이지이티에스(주), KG이티에스(주) 표기를 코어엔텍 주식회사(시흥 정왕동, 2023 전국 처리업체 현황 등재)로 합침. 근거는 KG ETS 환경에너지사업부가 2022년 물적분할되어 E&F PE에 매각된 뒤 코어엔텍으로 사명이 바뀐 사실(언론 보도 dealsite.co.kr/articles/101456, 코어엔텍 소재지와 사업이 같음). 등기 원부로는 대조하지 않았다. (2) 리뉴에너지매트로 주식회사를 리뉴에너지메트로 주식회사로 합침(표기 오타, 공식 목록의 업체명과 한 글자 차이).
- 폐기물군: `scripts/wastegroup.py`. 지역, 처리업체 통합: `scripts/analyze_flows.py` 함수를 그대로 가져다 썼다. 처리방식만 `demo_build.py`의 `method_permit`(복수 허가 규칙)으로 바꿨다.
- 검증(빌드 끝에 출력, assert): 고유 flow_id 4,575, 가중합 4,575.0, 공장 1,234, 처리업체 803, 안산 안 16.8%, 경기 밖 34.5%, 안산 밖(위치 확인 행 기준) 80.9%, 상위 10곳 24.1%, 태움 대 물질 재활용 30.0 대 26.9, 같은 종류 다른 처리 24.6%, 좌표가 없으면 거리도 없음, 단가표에 시나리오 행 없음. W1 값(안산 안 17.1, 경기 밖 36.4, 안산 밖 81.2, 상위 10곳 24.6, 태움 33.3 대 물질 27.7, 같은 종류 다른 처리 26.6)과 다른 이유는 별칭 규칙(지역 미확인 증가)과 복수 허가 규칙이다.

## 2. 파일과 열

### factories.csv (1,234행, 배출 공장 1곳 1행)

| 열 | 설명 |
|---|---|
| id | F0001~ |
| name | 신고 사업장명 |
| address | 신고 주소(원본의 밑줄을 쉼표로) |
| dong | 주소 괄호 속 법정동 |
| lat, lng | WGS84. 확인된 좌표만, 없으면 null |
| coord_source | `datagokr 15170508(상호+도로명주소 일치)`: 공공데이터포털 15170508 배출신고 현황(2026-04-30)에서 상호와 도로명+건물번호가 모두 같은 지점. `datagokr 15170508(도로명주소 일치)`: 도로명+건물번호가 같은 지점(같은 건물). `OSM 건물(도로명+건물번호 일치)`: OSM Nominatim이 돌려준 객체의 도로명과 건물번호가 원 주소와 같은 경우. 없으면 빈 칸 |
| coord_verified | 좌표가 있으면 true, 없으면 null(true만 남김) |
| waste_types | 신고 폐기물 종류 원 표기, JSON 배열 문자열 |
| waste_groups | 폐기물군, JSON 배열 문자열 |
| n_waste_types, n_processors, n_flows | 신고 폐기물 종류 수, 고유 처리업체(회사) 수, 신고 행 수 |
| sheets | `사업장일반`, `지정` |

### processors.csv (803행, 처리업체 회사 1곳 1행)

| 열 | 설명 |
|---|---|
| id | P0001~ (2026 B 기준 행 수 많은 순) |
| name | 정규업체명(`processors_enriched.csv`의 `정규업체명`) |
| name_variants | 신고에 쓰인 이름 표기들(JSON) |
| sido, sigungu, address | 소재지(2023 전국 현황, 안산시 목록, 올바로 순) |
| lat, lng, coord_source, coord_verified | 공장과 같은 규칙. 안산 소재 업체는 datagokr 15170508, 그 밖은 OSM 건물 일치만(datagokr 15115362, 15051574의 좌표 포함 목록도 대조했으나 일치 0건). 소재지를 모르거나 주소에 도로명+건물번호가 없으면 null |
| business_type | 2023 현황 업종(없으면 올바로 업종코드) |
| method | 2026 B 흐름에서 이 업체로 가는 행의 처리방식 중 가장 많은 것. 값: 소각, 에너지회수, 물질재활용, 중간가공(R10), 매립, 기타 중간처분, 복수 허가, 자가처리, 미확인 |
| methods_2026 | 처리방식별 행 수(JSON). 같은 업체도 폐기물군에 따라 방식이 다를 수 있다 |
| permit_summary, r_types, r_types_by_group | 허가 요약, 재활용 R 유형, 폐기물군별 R 유형(근거 확인용) |
| incinerator_ton_per_day, landfill_m3, capacity | 2023 현황 소각 용량(톤/일), 매립 용량(m3) |
| confirmed | `confirm_status`가 "확인"으로 시작하면 true(공식 목록 일치) |
| confirm_status | 확인(2023 전국 현황), 확인(안산시 현황), 부분확인(올바로 처리자 등록), 미확인(별칭 매칭 제외), 미확인. `별칭높음`이 붙은 행은 위 별칭 규칙으로 남긴 합침. 업체 이름 대조 결과 표시이며 값을 만든 것은 아니다 |
| flows_2026, n_factories_2026 | 받는 신고 행(가중), 거래 공장 수 |

### flows.csv (4,620행 = 처리업체 링크, 고유 flow_id 4,575)

원본 1행에 처리업체가 k곳 적혀 있으면 k개 링크로 나누고 `weight = 1/k`. 비율은 **weight 합 / 4,575**로 구하면 W1과 같다.

| 열 | 설명 |
|---|---|
| link_id, flow_id | 링크 번호, 원본 신고 행 번호 |
| period, sheet | 2026-07, 사업장일반 또는 지정 |
| factory_id, processor_id | FK. 처리업체 칸이 빈 행은 processor_id 공란 |
| processor_name_raw | 신고 원문 처리업체 이름 |
| transporter, transporter_is_processor | 운반자, 운반자와 처리업체가 같은 회사인지 |
| waste_type, waste_group | 원 표기, 폐기물군 |
| method | 허가 업종 기준 처리방식(위 값). "물질 재활용(다른 폐기물군 허가)"는 물질재활용으로 묶고 `method_by_other_group_permit = true` |
| method_detail | 원 분류 |
| in_ansan, region | 처리업체 소재지 기준. region: 안산, 시흥, 경기 기타, 경기 밖, 미확인. `region_w1`은 W1 7구분 |
| distance_km | 공장과 처리업체 좌표가 모두 확인된 경우만 직선거리. 아니면 null |
| distance_quality | 거리가 있으면 `A 확인 좌표 간 직선`, 없으면 null |
| weight | 1/k |

### fit_candidates.csv (RE:FIT 추천 근거 목록)

대상: 지금 소각, 에너지회수, 매립으로 판정된 (공장, 폐기물군, 현재 처리업체) 조합. 복수 허가 행은 현재 방식을 정할 수 없으므로 대상에서 빠진다. 의료폐기물(법상 소각)과 "그 밖의 폐기물"(성분 불명 묶음)도 제외.
후보: 같은 폐기물군을 **자기 폐기물군 재활용 허가로 물질 재활용**(R1~R7, R11) 판정을 받은 경로로 이미 받고 있는 처리업체. 그 공장이 이미 그 폐기물군을 보내는 업체는 뺐다. 상위 3곳.

| 열 | 설명 |
|---|---|
| factory_id, factory_name, waste_group | |
| current_processor_id, current_processor_name, current_method | 현재 처리업체와 방식(소각, 에너지회수, 매립) |
| candidate_processor_id, candidate_name, candidate_sigungu | 후보 |
| rank | 1~3 |
| evidence_rows | 이 후보에 같은 폐기물군을 물질 재활용으로 보내는 **다른** 안산 공장 수 |
| distance_km, distance_quality | 공장과 후보 좌표가 모두 확인된 경우만. 아니면 null |
| candidate_confirmed | 후보 업체가 공식 목록에서 확인되었는지 |
| factory_already_recycles_group | 이 공장이 같은 폐기물군을 이미 다른 물질 재활용 업체에도 보내는지 |
| fit_score | 0~100, 아래 순위 규칙 |

**순위 규칙(fit_score)**. 데이터에서 바로 계산하는 정렬 규칙이며 금액이나 효과 추정이 아니다. 가중치는 화면에서 바꿀 수 있게 하는 것을 권한다.

```
fit_score = 100 x (0.5 x E + 0.3 x D + 0.2 x M)
E (실적 경로) = ln(1 + evidence_rows) / ln(1 + 그 폐기물군에서 가장 많은 evidence_rows)
D (거리)      = max(0, 1 - distance_km / 150), 거리가 null이면 0
M (처리방식)  = 0.6 x 전환 순위 + 0.4 x 후보 확인 가중
                전환 순위: 현재 매립 1.0, 소각 0.8, 에너지회수 0.6
                후보 확인 가중: confirmed 1.0, 아니면 0.5
```

순위는 fit_score, 동점이면 evidence_rows, 거리 순. 지금은 처리업체 좌표가 적어 대부분 D = 0이다.

### group_fit.csv (공동 수거, 공동 계약 후보)

같은 폐기물군을 신고한 공장 가운데 **좌표가 확인된 공장**만 썼다. 의료폐기물 제외. 폐기물군마다 반복: 반경 2km 안 이웃이 가장 많은 공장을 씨앗으로 가까운 순 최대 10곳을 묶고, 중심에서 2km 넘는 공장은 빼고, 3곳 이상이면 그룹으로 확정한 뒤 남은 공장으로 다시 반복. 공장 규모(소량 여부)는 공개 자료에 없어서 묶음 조건에 넣지 않았다.

| 열 | 설명 |
|---|---|
| group_id, waste_group | |
| factory_ids | JSON 배열 |
| n | 3~10 |
| centroid_lat, centroid_lng, max_dist_km | 구성 공장 평균 좌표, 중심에서 가장 먼 공장까지 거리 |
| dongs | 법정동 |
| current_methods | 구성 공장의 그 폐기물군 처리방식별 행 수(JSON) |
| shared_processor_ids | 구성 공장 2곳 이상이 이미 같이 쓰는 처리업체(공동 계약 시작점) |
| n_distinct_processors | 구성 공장들이 쓰는 처리업체 수 |

한 공장이 여러 폐기물군 그룹에 들어갈 수 있다.

### unit_prices.csv (원문 단가)

원문에 적힌 단가만 원문 단위 그대로 옮겼다. 부가세와 운반비 별도가 원칙.

| 열 | 설명 |
|---|---|
| category | 고시 처리단가, 지정 공공처리시설 반입수수료, 지정 공공처리시설 운반비, 공제조합 소각처리단가(지정, 일반, 건설), 민간 평균 처리단가 |
| item | 원문 품목명. 줄이 나뉜 품목은 `광재(일반)`처럼 원문 구조대로 묶었다 |
| waste_group | 이름이 같은 시연 폐기물군(대응이 애매하면 공란) |
| method | 반입수수료와 공제조합 표는 소각, 매립, 운반. 고시 처리단가 행은 적용 사업자 구분(수집운반, 처분업자 / 재활용업자 / 처리신고자) |
| price_won, price_min, price_max, unit | 원/톤(운반 변동비는 원/톤/10km). 원문이 범위로 적은 매립 반입수수료는 min, max만 |
| year | 고시 적용 연도 또는 자료 연도 |
| source_code, source, source_nature | W2 출처 번호, 출처명, 성격(고시, 업계(공제조합), 시장(증권사 보고서)) |
| source_file, source_location | 원문 파일(`raw/unit_price/`)과 원문 안 위치(별표 구분, 분류번호, 표 이름) |
| note | 원문 단서 |

- 고시 처리단가(2022 적용분, 2027-01-01 시행분)는 `pdftotext`로 원문을 읽어 빌드할 때 그대로 파싱한다. 2019년 고시(`allbaro_2019-254.pdf`)는 스캔 이미지라 넣지 않았다.
- **물질재활용 위탁 시장 단가: 공개 단가 없음.** 고시의 "재활용업자" 단가는 방치폐기물 보증보험금 산출용이다.

### waste_chips.csv, volume_options.csv (진단 화면 입력)

정의는 `scripts/chips_data.py`. 진단 화면에서 공장이 고르는 품목 칩 17개와 한 달 용기 개수 5지선다다.

**근거 조사 결과: 용기 1개를 kg으로 바꾸는 공식 환산계수는 없다.** 그래서 모든 칩의 `unit_kg`, `container_volume_l`, `bulk_density_t_m3`, `fill_ratio`는 비어 있고 `basis = 공식 환산 근거 없음`이다. 화면은 용기 개수로 금액이나 톤수를 계산하지 말고, 계량표나 올바로 인계서에 적힌 무게(kg)를 입력받는다.

| 확인한 근거 | 내용 | 쓸 수 있나 |
|---|---|---|
| 폐기물관리법 시행규칙 별지 제36호서식(사업장폐기물 관리대장) 작성방법, 제42호서식도 같음 | "양은 무게단위인 톤(액체 상태인 경우에는 비중을 고려하여 무게로 환산)으로 적고". 비중 값은 없음 | 무게 입력의 법적 근거로만 씀 |
| 기후에너지환경부고시 제2025-165호 지정폐기물 공공처리시설 반입수수료, 다. 운반비 | 비중 0.6, 0.8 구분은 폐합성수지 등 운반비 등급. 폐기물 종류별 비중 값이 아님 | 못 씀 |
| 환경부 쓰레기 수수료 종량제 시행지침(2022-01-10 개정) | 75L 19kg, 50L 13kg 이하(0.25kg/L 이하) 예시. 생활계 종량제봉투 무게 상한 | 못 씀(상한이고 대상이 다름) |
| KS T ISO 15750-1, -2 강제 드럼 | 최소 용량 208, 210, 216.5 L(오픈), 212, 216.5, 230 L(밀폐). 내용물 중량 없음 | 용기 이름 표기에만 씀 |
| KS T ISO 21898 톤백(FIBC) | 재질, 구조, 시험 표준. 용량 값 없음. "1톤"은 제조사 안전작업하중 | 용기 이름 표기에만 씀 |
| PP 마대 | KS 규격 없음 | 없음 |
| 지자체 대형폐기물 수수료(대구 달서구 마대 20kg, 충남 금산군 PP마대 40kg) | 가정 배출 수수료 항목, 지자체마다 다름 | 못 씀 |

전국 폐기물 통계조사 겉보기밀도 표, 폐기물 발생 및 처리현황 작성지침, 올바로 단위 환산 안내도 찾아봤지만 사업장폐기물 폐기물군별 값은 확인하지 못했다.

waste_chips.csv 열: id, label(화면 이름), waste_group, container(용기 예시와 규격), container_volume_l, bulk_density_t_m3, fill_ratio, unit_kg(공식 근거가 생기면 `용량 L x 비중 t/m3`로 빌드가 계산, 지금은 모두 빈 칸), basis, source, source_url, display_text(화면 문구).

화면 문구 예: "PP 마대 개수로는 무게를 계산하지 않아요. 공식 환산 근거가 없어요. 계량표나 올바로 인계서에 적힌 무게(kg)를 넣어 주세요(폐기물관리법 시행규칙 별지 제36호서식: 양은 톤으로 기록)". 액상(폐유, 폐유기용제, 폐페인트, 폐산)은 "액체는 비중을 고려해 무게로 환산해 적게 되어 있으니 계량 무게(kg)를 넣어 주세요".

volume_options.csv(5행): 1개, 2~4개, 5~9개, 10~19개, 20개 이상. `representative_count`는 구간 하한(값을 부풀리지 않는 화면 규칙). 용기 개수는 참고 정보로만 저장하고, kg 환산은 `unit_kg`가 있는 칩에서만 한다(지금은 없음).

### summary.json (대시보드 핵심 지표)

모든 값에 `basis`(`신고 건수 집계` 또는 `공식 통계 원값`)를 붙였다. 주요 키: `counts`, `region_pct`(안산 16.8, 시흥 5.6, 경기 기타 31.0, 경기 밖 34.5, 미확인 12.1), `outside_ansan_pct_of_located`(80.9), `method_pct`(복수 허가 포함), `burn_vs_material`(30.0 대 26.9), `same_type_different_treatment`(24.6), `top10_processor_share_pct`(24.1), `alias_rule`(제외하고 남긴 별칭 이름), `transporter_is_processor_pct`, `trend_2023_2026`(시점별 B 기준 지표), `official_stats_2024_ansan_ton`(2024 안산시 사업장배출시설계와 지정폐기물 발생량, 재활용, 소각, 매립, 기타, 공공, 자가, 위탁 처리 톤수 원값), `coords`(좌표 출처별 개수와 확인 좌표 수), `distance_coverage_pct`(거리 계산 가능 행 비율), `fit_candidates`, `group_fit`.

### refit_demo.sqlite

위 8개 CSV와 같은 테이블 + `summary`(json 1행). 모든 열이 TEXT로 들어가 있으니 숫자 비교 시 CAST.

## 3. Supabase에 넣기

1. SQL Editor에서 아래 CREATE TABLE 실행.
2. Table Editor의 CSV 가져오기로 factories → processors → flows → fit_candidates → group_fit → unit_prices → waste_chips → volume_options 순서로 올린다(FK 순서). 또는 `psql`로 `\copy factories from 'factories.csv' csv header` 식으로 넣는다. 빈 칸은 NULL로 들어간다.
3. `summary.json`은 정적 파일로 두거나 `app_summary` 테이블에 jsonb 1행으로 넣는다.

```sql
create table factories (
  id text primary key, name text not null, address text, dong text,
  lat double precision, lng double precision, coord_source text, coord_verified boolean,
  waste_types jsonb, waste_groups jsonb, n_waste_types int, n_processors int, n_flows int,
  sheets jsonb
);
create table processors (
  id text primary key, name text not null, name_variants jsonb, sido text, sigungu text, address text,
  lat double precision, lng double precision, coord_source text, coord_verified boolean, business_type text,
  method text, methods_2026 jsonb, permit_summary text, r_types text, r_types_by_group text,
  incinerator_ton_per_day double precision, landfill_m3 double precision, capacity text,
  confirmed boolean, confirm_status text, flows_2026 double precision, n_factories_2026 int
);
create table flows (
  link_id int primary key, flow_id int not null, period text, sheet text,
  factory_id text references factories(id), processor_id text references processors(id),
  processor_name_raw text, transporter text, transporter_is_processor boolean,
  waste_type text, waste_group text, method text, method_detail text, method_by_other_group_permit boolean,
  in_ansan boolean, region text, region_w1 text, distance_km double precision, distance_quality text,
  weight double precision
);
create table fit_candidates (
  id bigint generated always as identity primary key,
  factory_id text references factories(id), factory_name text, waste_group text,
  current_processor_id text references processors(id), current_processor_name text, current_method text,
  candidate_processor_id text references processors(id), candidate_name text, candidate_sigungu text,
  rank int, evidence_rows int, distance_km double precision, distance_quality text,
  candidate_confirmed boolean, factory_already_recycles_group boolean, fit_score double precision
);
create table group_fit (
  group_id text primary key, waste_group text, factory_ids jsonb, n int,
  centroid_lat double precision, centroid_lng double precision, max_dist_km double precision,
  dongs jsonb, current_methods jsonb, shared_processor_ids jsonb, n_distinct_processors int
);
create table unit_prices (
  id text primary key, category text, item text, waste_group text, method text,
  price_won double precision, price_min double precision, price_max double precision, unit text,
  year int, source_code text, source text, source_nature text, source_file text, source_location text, note text
);
create table waste_chips (
  id text primary key, label text not null, waste_group text, container text,
  container_volume_l double precision, bulk_density_t_m3 double precision, fill_ratio double precision,
  unit_kg double precision, basis text, source text, source_url text, display_text text
);
create table volume_options (
  id text primary key, label text not null, min_count int, max_count int, representative_count int, note text
);
create index on flows (factory_id); create index on flows (processor_id); create index on flows (waste_group);
create index on fit_candidates (factory_id, waste_group, rank);
```

fit_candidates CSV에는 id 열이 없으니 가져오기 때문에 identity 열은 비워 둔다. 공개 시연이면 RLS를 켜고 `select`만 anon에 허용한다.

자주 쓸 쿼리 예:

```sql
-- 안산 안 처리 비율(신고 건수 집계)
select round(100 * sum(weight) filter (where in_ansan) / 4575.0, 1) from flows;
-- 공장 1곳의 추천
select * from fit_candidates where factory_id = 'F0001' order by waste_group, rank;
-- 지도에 올릴 수 있는 공장(확인 좌표)
select id, name, lat, lng from factories where coord_verified;
```

## 4. 출처

- 흐름: 안산시 사전정보공표 폐기물 배출자 신고현황(산단환경과) 2026-07-10(게시글 1677014), 2023-07, 2024-09, 2025-07(추이). `flows/`
- 처리업체 속성: `processors_enriched.csv`(2023 전국 폐기물 처리업체 현황, 안산시 처리업체 현황 2026-07, 올바로 공개 업체검색, 별칭표). 상세는 W1 1장.
- 공장 좌표: 공공데이터포털 「경기도 안산시_사업장 폐기물 배출신고 현황_20260430」(15170508). `raw/datagokr_15170508/`
- 처리업체 좌표 대조: 공공데이터포털 15115362, 15051574(위도, 경도 포함 목록, 일치 0건). `raw/datagokr_202611/`
- 건물 단위 조회: OpenStreetMap Nominatim(© OpenStreetMap contributors, ODbL). 캐시 `raw/geocode_osm_202611/nominatim_bldg_cache.jsonl`. 이전 빌드의 도로, 리동, 읍면 단위 캐시(`nominatim_cache.jsonl`)는 쓰지 않는다.
- 공식 통계: 환경부 2024 전국 폐기물 발생 및 처리현황(안산시 행). `data/ansan_배출시설계_series.csv`, `data/ansan_지정_series.csv`
- 단가: unit_prices.csv `source`, `source_file`

## 5. 좌표 규칙과 현황

- 규칙: 좌표는 **그 사업장 주소의 건물 위치로 확인된 것만** 남긴다. 확인 방법은 (1) 공공데이터 좌표 중 도로명+건물번호가 원 주소와 같은 지점, (2) OSM 객체의 도로명과 건물번호가 원 주소와 같은 경우 둘뿐이다. 이름만 같은 공공데이터 지점, 도로 중간점, 리동 읍면 중심, 동 중심, 단원구 중심, 시군구 중심은 모두 지우고 null로 두었다. 지어낸 좌표는 없다.
- 현황(2026-11-07 빌드): 공장 1,234곳 중 1,123곳(91.0%) = datagokr 상호+도로명주소 일치 1,066, 도로명주소 일치 55, OSM 건물 일치 2. 좌표 없음 111(아래 좌표 정제로 지운 15곳 포함. 이전 빌드의 OSM 도로 단위 76, 동 중심 13, 단원구 중심 6, 이름만 일치 3을 지움). 처리업체 803곳 중 32곳(4.0%) = datagokr 상호+도로명주소 일치 10, 도로명주소 일치 1, OSM 건물 일치 21. 좌표 없음 771. flows 가중 기준: 공장 좌표 있음 96.4%, 처리업체 좌표 있음 14.5%, 거리 계산 가능 14.3%. 처리업체 OSM 건물 조회 대상은 도로명+건물번호가 있는 주소뿐이었고, OSM이 같은 건물번호를 돌려준 경우는 일부였다.
- 더 채우는 방법을 찾아본 결과: 행정안전부 주소기반산업지원서비스의 좌표 자료(내비게이션용DB, 위치정보요약DB, 도로명주소 출입구 정보)는 내려받기 전에 본인인증이 필요해 이번에는 쓰지 못했다. 이 자료를 받으면 처리업체 주소를 도로명+건물번호로 바로 맞출 수 있어 가장 확실한 다음 단계다. 도로명주소 API와 브이월드 지오코더는 인증키가 필요하다. OSM은 한국 건물번호 정보가 적어 일치율이 낮다. 주소가 지번만 있는 처리업체는 지번 기반 공식 자료가 있어야 채울 수 있다.

### 좌표 정제 2026-11-07

- 규칙(`scripts/placeholder_coords.py`, keep-void2026): 공공데이터 15170508 원본(`raw/datagokr_15170508/ansan_baechul_20260430.csv`)에서 소수점 6자리로 반올림한 같은 좌표를 서로 다른 '도로명+건물번호'(쉼표, 괄호 앞까지) 2개 이상이 쓰면 기본값 좌표로 보고, 그 좌표를 쓰는 모든 행의 위도, 경도를 비운 뒤 빌드한다. 같은 건물 입주(주소 같음)는 해당하지 않는다.
- 원본에서 걸린 좌표: 37.305026, 126.793909(서로 다른 주소 32개, 106행), 37.303163, 126.812855(주소 2개, 7행). 합계 113행 비움.
- 빌드 방법: `python3 -I scripts/placeholder_coords.py clean 원본.csv 정제.csv`로 만든 정제본을 원본 자리에 두고 `python3 -I scripts/demo_build.py <waste_dir>`. 결과 factories.csv에 `check`를 돌리면 OK.
- 바뀐 수: 확인 좌표 공장 1,138 → 1,123(F0180, F0256, F0308, F0384, F0460, F0643, F0677, F0686, F0701, F0781, F0851, F0868, F1141, F1183, F1211 좌표 삭제. F1221은 같은 도로명주소의 다른 원본 행 좌표로 이동), 좌표 확인 비율 92.2% → 91.0%, 상호+도로명 1,080 → 1,066, 도로명 56 → 55, 좌표 없음 96 → 111, 공동 수거 묶음 241 → 239, 거리 계산 가능 흐름 14.4% → 14.3%, 공장 좌표 있는 흐름 97.3% → 96.4%, distance_km 있는 링크 662 → 657.
- G0159 묶음은 G0158로 번호만 바뀌었다(구성 공장 10곳, 좌표, 중심 37.314273, 126.756603, 반경 0.2km, 처리업체 20곳 같음). `group_G0158_points.json`.
- 바뀌지 않은 수: 공장 1,234, 처리업체 803, 신고 4,575, 처리업체 확인 좌표 32, 안산 안 16.8%, 안산 밖 80.9%, 경기 밖 34.5%, 소각+에너지회수 대 물질재활용 30.0 대 26.9, 같은 종류 다른 처리 24.6%(1,126건), 공장당 처리업체 3.07, 운반=처리 35.7%, home_waste_stats.json 전체.
- 이전 판: `research/waste/demo_backup_2026-11-07_before_coordfix/`
